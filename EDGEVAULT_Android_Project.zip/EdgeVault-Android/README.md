# EDGEVAULT Android project

This Android Studio project wraps the supplied EDGEVAULT HTML app in an Android WebView and adds a native Google Mobile Ads banner. The AdMob app ID and banner unit currently use Google's published **test IDs only**. No real ad revenue can be generated until you register the app in your AdMob account and change both IDs.

## What's included

- The uploaded HTML trading journal is copied into `app/src/main/assets/index.html`; the original upload is preserved at `source/EDGEVAULT_original.html`.
- Native Android notification bridge for the app's existing market-session and journal reminders. Android may delay reminders when the app is backgrounded or force-stopped; this project does not promise exact alarms after the app is fully closed.
- Native Save As handling for CSV / JSON / HTML exports.
- Android file chooser support for chart screenshots, videos and backup import; runtime microphone permission for voice notes.
- Adaptive banner at the bottom, using the official AdMob test banner ID.
- GitHub Actions workflow that builds a debug APK and release AAB.
- API 36 target, matching Google Play's requirement for new app submissions since 31 August 2026.

## Build with GitHub Actions

1. Upload the **contents** of this folder into your `raeesshahzaib9245/Edge-Vault` repository (the `settings.gradle` file should be in the repository root). If the repository already has unrelated files, don't overwrite them blindly.
2. On GitHub, open **Actions** and run **Build EDGEVAULT Android app** with **Run workflow**. A push to `main` or `master` also starts the workflow.
3. When the run finishes, download the artifact named `edgevault-android-build`. It contains a debug APK for phone testing and a release AAB.
4. Without release-signing secrets, the AAB is **unsigned** and cannot be uploaded to Google Play. Use the signing steps below before generating the Play-ready bundle.

## Secure release signing

Create a signing key once on a trusted computer, store its password securely, and keep the keystore file private. Do not commit the keystore or passwords into the repository.

Example command (run on your own trusted computer):

```bash
keytool -genkeypair -v -keystore edgevault-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias edgevault
```

Convert the keystore file to a single-line Base64 string and add these repository **Actions secrets** under **Settings → Secrets and variables → Actions**:

- `ANDROID_KEYSTORE_BASE64`: Base64 output of your `.jks` file
- `ANDROID_KEYSTORE_PASSWORD`: keystore password
- `ANDROID_KEY_ALIAS`: `edgevault` (or the alias you chose)
- `ANDROID_KEY_PASSWORD`: key password

Re-run the workflow. When the secrets and keystore are present, Gradle signs the release AAB. Keep a secure offline backup of the key. If using Google Play App Signing, enroll when Play Console offers it; the upload key still needs to remain secure.

## Before publishing

1. Create the app in AdMob and replace the sample App ID in `app/src/main/AndroidManifest.xml` (`com.google.android.gms.ads.APPLICATION_ID`). Replace `TEST_BANNER_AD_UNIT` in `MainActivity.java` with your own banner ad-unit ID. Keep Google's test IDs while developing and testing.
2. Select the permanent Android package ID before the first Play Store release. It is currently `com.raeesshahzaib.edgevault`; changing it after publishing means a different app.
3. Add a real privacy policy URL and complete Play Console's Data safety, ads declaration, app-content and content-rating forms. Re-check consent requirements before enabling production ads, particularly for users in regions that require consent.
4. Test on a real Android phone: open and save a trade, select a screenshot, record a voice note, export CSV/JSON/HTML, restart the app and check that local data remains. Test Android notification permission too.
5. The app keeps journal data locally on the device. Clearing app storage or uninstalling the app may remove data; use the app's backup/export flow.

## Version / build details

- App label: `EDGEVAULT`
- Application ID: `com.raeesshahzaib.edgevault`
- `minSdk`: 24
- `compileSdk` / `targetSdk`: 36
- Android Gradle Plugin: 8.13.2
- Gradle: 8.13
- Android SDK Platform / Build Tools: 36 / 36.0.0
- Java: 17
- Google Mobile Ads SDK (Legacy): 25.4.0

## Current verification status

The source project and workflow files have been prepared and statically inspected. This execution environment has no Android SDK or Gradle installation, so an APK/AAB has **not** been built or device-tested here. Use the GitHub Actions workflow or Android Studio on a machine with the Android SDK to run the actual build.
