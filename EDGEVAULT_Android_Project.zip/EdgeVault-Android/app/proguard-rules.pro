# ProGuard/R8 rules can be added here if release minification is enabled.
