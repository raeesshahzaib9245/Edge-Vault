/* Minimal same-origin service worker for web/PWA compatibility. Android notifications use the native bridge. */
self.addEventListener('install', event => { self.skipWaiting(); });
self.addEventListener('activate', event => { event.waitUntil(self.clients.claim()); });
