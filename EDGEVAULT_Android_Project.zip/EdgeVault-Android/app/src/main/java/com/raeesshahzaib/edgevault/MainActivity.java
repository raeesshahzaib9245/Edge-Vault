package com.raeesshahzaib.edgevault;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.webkit.WebViewAssetLoader;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final String ASSET_HOST = "appassets.androidplatform.net";
    private static final String NOTIFICATION_CHANNEL = "edgevault_reminders";
    private static final int REQUEST_FILE_CHOOSER = 8101;
    private static final int REQUEST_SAVE_TEXT = 8102;
    private static final int REQUEST_NOTIFICATIONS = 8103;
    private static final int REQUEST_AUDIO = 8104;
    private static final String TEST_BANNER_AD_UNIT = "ca-app-pub-3940256099942544/6300978111";

    private WebView webView;
    private AdView adView;
    private ValueCallback<Uri[]> filePathCallback;
    private PermissionRequest pendingMediaPermissionRequest;
    private String pendingSaveName;
    private String pendingSaveMime;
    private String pendingSaveText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createNotificationChannel();

        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(234, 240, 251));
        window.setNavigationBarColor(Color.rgb(234, 240, 251));
        window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(234, 240, 251));
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, windowInsets) -> {
            Insets bars = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return windowInsets;
        });

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(234, 240, 251));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setWebViewClient(makeWebViewClient());
        webView.setWebChromeClient(makeWebChromeClient());
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.addJavascriptInterface(new AndroidNotifications(), "AndroidNotifications");
        webView.addJavascriptInterface(new AndroidFiles(), "AndroidFiles");

        root.addView(webView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout adStrip = new LinearLayout(this);
        adStrip.setOrientation(LinearLayout.VERTICAL);
        adStrip.setGravity(Gravity.CENTER);
        adStrip.setBackgroundColor(Color.rgb(234, 240, 251));
        adView = new AdView(this);
        adView.setAdUnitId(TEST_BANNER_AD_UNIT);
        int screenWidthDp = (int) (getResources().getDisplayMetrics().widthPixels
                / getResources().getDisplayMetrics().density);
        adView.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, screenWidthDp));
        adStrip.addView(adView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        root.addView(adStrip, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        setContentView(root);

        WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        this.assetLoader = assetLoader;
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");

        // Use Google-provided test IDs only. Do not use production ads for testing.
        MobileAds.initialize(getApplicationContext(), status -> runOnUiThread(() -> {
            if (adView != null) {
                adView.loadAd(new AdRequest.Builder().build());
            }
        }));
    }

    private WebViewAssetLoader assetLoader;

    private WebViewClient makeWebViewClient() {
        return new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view,
                    WebResourceRequest request) {
                if (assetLoader != null) {
                    android.webkit.WebResourceResponse response = assetLoader.shouldInterceptRequest(request.getUrl());
                    if (response != null) return response;
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (ASSET_HOST.equals(uri.getHost())) return false;
                if ("https".equalsIgnoreCase(uri.getScheme()) || "http".equalsIgnoreCase(uri.getScheme())) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (ActivityNotFoundException ignored) { }
                }
                // Never let external pages run inside the WebView where the local JS bridge exists.
                return true;
            }
        };
    }

    private WebChromeClient makeWebChromeClient() {
        return new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent;
                try {
                    intent = params.createIntent();
                } catch (Exception e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "Could not open file picker.", Toast.LENGTH_SHORT).show();
                    return false;
                }
                try {
                    startActivityForResult(intent, REQUEST_FILE_CHOOSER);
                    return true;
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "No file picker is available on this device.", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean audioOnly = true;
                    List<String> grantable = new ArrayList<>();
                    for (String resource : request.getResources()) {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) grantable.add(resource);
                        else audioOnly = false;
                    }
                    if (!audioOnly || grantable.isEmpty()) {
                        request.deny();
                        return;
                    }
                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO)
                            == PackageManager.PERMISSION_GRANTED) {
                        request.grant(grantable.toArray(new String[0]));
                    } else {
                        if (pendingMediaPermissionRequest != null) pendingMediaPermissionRequest.deny();
                        pendingMediaPermissionRequest = request;
                        ActivityCompat.requestPermissions(MainActivity.this,
                                new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO);
                    }
                });
            }
        };
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(NOTIFICATION_CHANNEL,
                    "EDGEVAULT reminders", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Trading session and journal reminders from EDGEVAULT");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private String notificationPermissionState() {
        if (Build.VERSION.SDK_INT < 33) {
            return NotificationManagerCompat.from(this).areNotificationsEnabled() ? "granted" : "denied";
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED) {
            return NotificationManagerCompat.from(this).areNotificationsEnabled() ? "granted" : "denied";
        }
        return shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS) ? "denied" : "default";
    }

    private void resolveNotificationPermission(boolean granted) {
        if (webView == null) return;
        String value = granted ? "'granted'" : "'denied'";
        webView.evaluateJavascript("(function(){var r=window.__edgeVaultPermissionResult;if(r){window.__edgeVaultPermissionResult=null;r(" + value + ");}})();", null);
    }

    private void showNativeNotification(String title, String body, String tag) {
        if (!"granted".equals(notificationPermissionState())) return;
        NotificationManagerCompat manager = NotificationManagerCompat.from(this);
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int id = tag == null ? (int) System.currentTimeMillis() : tag.hashCode();
        PendingIntent pendingIntent = PendingIntent.getActivity(this, id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification notification = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title == null ? "EDGEVAULT" : title)
                .setContentText(body == null ? "Reminder" : body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body == null ? "Reminder" : body))
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .build();
        try {
            manager.notify("edgevault-" + (tag == null ? "reminder" : tag), id, notification);
        } catch (SecurityException ignored) {
            // User may revoke notifications while the app is open.
        }
    }

    private class AndroidNotifications {
        @JavascriptInterface
        public String permissionState() {
            return notificationPermissionState();
        }

        @JavascriptInterface
        public void requestPermission() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(MainActivity.this,
                        Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                    resolveNotificationPermission(NotificationManagerCompat.from(MainActivity.this).areNotificationsEnabled());
                } else {
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
                }
            });
        }

        @JavascriptInterface
        public void show(String title, String body, String tag) {
            runOnUiThread(() -> showNativeNotification(title, body, tag));
        }
    }

    private class AndroidFiles {
        @JavascriptInterface
        public void saveText(String fileName, String mimeType, String text) {
            if (text == null) text = "";
            if (text.length() > 8 * 1024 * 1024) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "This export is too large to save in one file.", Toast.LENGTH_LONG).show());
                return;
            }
            final String contents = text;
            final String safeName = sanitizeFileName(fileName);
            final String safeMime = (mimeType == null || mimeType.trim().isEmpty()) ? "text/plain" : mimeType;
            runOnUiThread(() -> {
                pendingSaveName = safeName;
                pendingSaveMime = safeMime;
                pendingSaveText = contents;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(safeMime);
                intent.putExtra(Intent.EXTRA_TITLE, safeName);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADownload"));
                }
                try {
                    startActivityForResult(intent, REQUEST_SAVE_TEXT);
                } catch (ActivityNotFoundException e) {
                    pendingSaveName = pendingSaveMime = pendingSaveText = null;
                    Toast.makeText(MainActivity.this, "No file saving app is available.", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    private String sanitizeFileName(String input) {
        String value = input == null ? "EDGEVAULT-export.txt" : input.replace('\\', '/');
        int slash = value.lastIndexOf('/');
        if (slash >= 0) value = value.substring(slash + 1);
        value = value.replaceAll("[^A-Za-z0-9._-]", "_");
        if (value.isEmpty()) value = "EDGEVAULT-export.txt";
        return value;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_FILE_CHOOSER) {
            if (filePathCallback == null) return;
            Uri[] results = (resultCode == RESULT_OK && data != null)
                    ? WebChromeClient.FileChooserParams.parseResult(resultCode, data) : null;
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            return;
        }
        if (requestCode == REQUEST_SAVE_TEXT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingSaveText != null) {
                Uri uri = data.getData();
                String content = pendingSaveText;
                pendingSaveName = pendingSaveMime = pendingSaveText = null;
                new Thread(() -> {
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new IllegalStateException("Unable to open selected file");
                        out.write(content.getBytes(StandardCharsets.UTF_8));
                        runOnUiThread(() -> Toast.makeText(MainActivity.this, "File saved successfully.", Toast.LENGTH_SHORT).show());
                    } catch (Exception e) {
                        runOnUiThread(() -> Toast.makeText(MainActivity.this, "Could not save the file. Please try again.", Toast.LENGTH_LONG).show());
                    }
                }, "edgevault-save-file").start();
            } else {
                pendingSaveName = pendingSaveMime = pendingSaveText = null;
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_NOTIFICATIONS) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            resolveNotificationPermission(granted && NotificationManagerCompat.from(this).areNotificationsEnabled());
        } else if (requestCode == REQUEST_AUDIO) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            PermissionRequest request = pendingMediaPermissionRequest;
            pendingMediaPermissionRequest = null;
            if (request != null) {
                if (granted) request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                else request.deny();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
        if (adView != null) adView.resume();
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        if (adView != null) adView.pause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
        if (pendingMediaPermissionRequest != null) {
            pendingMediaPermissionRequest.deny();
            pendingMediaPermissionRequest = null;
        }
        if (adView != null) {
            adView.destroy();
            adView = null;
        }
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidNotifications");
            webView.removeJavascriptInterface("AndroidFiles");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
